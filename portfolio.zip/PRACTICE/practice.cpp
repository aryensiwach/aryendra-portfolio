// Online C++ compiler to run C++ program online
#include <iostream>
#include <stack>
using namespace std;
int main() {
    
    int arr[5]={2,4,6,8,10};
    
    for(int i=0;i<10;i++){
        cout<<arr[i]<<" ";
    }
    

    return 0;
}